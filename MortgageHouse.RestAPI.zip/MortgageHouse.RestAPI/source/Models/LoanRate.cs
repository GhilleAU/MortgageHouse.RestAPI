namespace MortgageHouse.RestAPI.Models
{
    public class LoanRate
    {
        public string LoanType { get; set; } = string.Empty;
        public int Term { get; set; }
        public double InterestRate { get; set; } 
        public double ComparisonRate { get; set; }
        public string Lender { get; set; } = string.Empty;
        public float MonthlyRepayment { get; set; }
    }
}