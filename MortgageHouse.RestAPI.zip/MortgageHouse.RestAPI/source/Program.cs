using MortgageHouse.RestAPI.Models;

namespace MortgageHouse.RestAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Create an instance of WebApplication which is used to configure http-pipelining and route
            var builder = WebApplication.CreateBuilder(args);

            // Invoke .Build so that we can register our services and get an instance of our web application
            var webApplication = builder.Build(); 

            // Add an GET endpoint for the route /api/rates which requires loanType and term as query paremeters
            // When accessed invoke GetMockupRates which in production would be connected to a database allowing for query of actual loan data.
            // In this case we're going to use the Linq method .Where to filter and return the mockup data for what the request is looking for.
            webApplication.MapGet("/api/rates", (string loanType, int term) =>
            {
                var loanRates = GetMockupRates()
                    .Where(loanRate => loanRate.LoanType == loanType && loanRate.Term == term).ToList();
                
                return loanRates.Count < 1 ? Results.NotFound() : Results.Ok(loanRates);
            });
        
            // Initialize and run the application
            webApplication.Run();
        }

        
        // Method for returning mockup data
        private static IReadOnlyList<LoanRate> GetMockupRates() =>
            new List<LoanRate>
            {
                new()
                {
                    LoanType = "owner-occupied",
                    Term = 30,
                    InterestRate = 6.25,
                    ComparisonRate = 6.30,
                    Lender = "Mortgage House",
                    MonthlyRepayment = 2150.75f
                },
                new()
                {
                    LoanType = "owner-occupied",
                    Term = 30,
                    InterestRate = 6.10,
                    ComparisonRate = 6.15,
                    Lender = "Mortgage House",
                    MonthlyRepayment = 2100.50f
                },
                new()
                {
                    LoanType = "owner-occupied",
                    Term = 25,
                    InterestRate = 6.05,
                    ComparisonRate = 6.10,
                    Lender = "Mortgage House",
                    MonthlyRepayment = 2250.00f
                },
                new()
                {
                    LoanType = "owner-occupied",
                    Term = 25,
                    InterestRate = 5.95,
                    ComparisonRate = 6.00,
                    Lender = "Mortgage House",
                    MonthlyRepayment = 2200.35f
                },
                new()
                {
                    LoanType = "owner-occupied",
                    Term = 20,
                    InterestRate = 5.85,
                    ComparisonRate = 5.90,
                    Lender = "Mortgage House",
                    MonthlyRepayment = 2350.45f
                },
                new()
                {
                    LoanType = "owner-occupied",
                    Term = 20,
                    InterestRate = 5.70,
                    ComparisonRate = 5.75,
                    Lender = "Mortgage House",
                    MonthlyRepayment = 2300.10f
                },
            };
    }
}